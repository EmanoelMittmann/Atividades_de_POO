
namespace Trabalho.Models.Repository
{
    public interface IBaseRepository<Entity>
        where Entity: class
    {
        Task<Entity> GetByIdAsync(int id);
        Task<List<Entity>> GetAll();
        void Create(Entity entity);
        void Update(Entity entity);
        void Delete(int id);
    }
}
