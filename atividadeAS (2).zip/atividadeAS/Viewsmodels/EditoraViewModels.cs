using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace atividadeAS.Viewsmodels
{
    public class EditoraViewModels
    {
        public int Id_Edit { get; set; }
        public string nome {get; set;}
        public string cidade{ get; set;}
    }
}