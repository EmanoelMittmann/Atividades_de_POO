using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace atividadeAS.Viewsmodels
{
    public class AutorViewModels
    {
        public string Nome { get; set; }
    }
}