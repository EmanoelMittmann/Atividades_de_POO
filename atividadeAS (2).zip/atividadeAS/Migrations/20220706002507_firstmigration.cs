﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace atividadeAS.Migrations
{
    public partial class firstmigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "autor",
                columns: table => new
                {
                    Id_Autor = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Nome = table.Column<string>(type: "NVARCHAR", maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_autor", x => x.Id_Autor);
                });

            migrationBuilder.CreateTable(
                name: "editora",
                columns: table => new
                {
                    Id_Edit = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    nome = table.Column<string>(type: "NVARCHAR", maxLength: 50, nullable: true),
                    cidade = table.Column<string>(type: "varchar", maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_editora", x => x.Id_Edit);
                });

            migrationBuilder.CreateTable(
                name: "genero",
                columns: table => new
                {
                    Id_Genero = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    nome = table.Column<string>(type: "NVARCHAR", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_genero", x => x.Id_Genero);
                });

            migrationBuilder.CreateTable(
                name: "user",
                columns: table => new
                {
                    Id_user = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    CPF = table.Column<string>(type: "NVARCHAR", maxLength: 50, nullable: true),
                    Nome = table.Column<string>(type: "NVARCHAR", maxLength: 30, nullable: true),
                    Endereco = table.Column<string>(type: "NVARCHAR", maxLength: 30, nullable: true),
                    Telefone = table.Column<string>(type: "NVARCHAR", maxLength: 11, nullable: true),
                    Email = table.Column<string>(type: "NVARCHAR", maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_user", x => x.Id_user);
                });

            migrationBuilder.CreateTable(
                name: "Livro",
                columns: table => new
                {
                    Id_Livro = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Titulo = table.Column<string>(type: "NVARCHAR", maxLength: 50, nullable: true),
                    Num_edit = table.Column<int>(type: "INTEGER", nullable: false),
                    Volume = table.Column<int>(type: "INTEGER", nullable: false),
                    EditoraId = table.Column<int>(type: "integer", nullable: false),
                    GeneroId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Livro", x => x.Id_Livro);
                    table.ForeignKey(
                        name: "FK_Livro_Editora",
                        column: x => x.EditoraId,
                        principalTable: "editora",
                        principalColumn: "Id_Edit",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Livro_Genero",
                        column: x => x.GeneroId,
                        principalTable: "genero",
                        principalColumn: "Id_Genero",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "emprestimo",
                columns: table => new
                {
                    Id_empres = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    LivroId = table.Column<int>(type: "integer", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    data_emprestimo = table.Column<DateTime>(type: "date", nullable: false),
                    data_entrega = table.Column<DateTime>(type: "SMALLDATETIME", nullable: false),
                    prazo = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_emprestimo", x => x.Id_empres);
                    table.ForeignKey(
                        name: "FK_Address_Customer",
                        column: x => x.LivroId,
                        principalTable: "Livro",
                        principalColumn: "Id_Livro",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Emprestimo_Usuario",
                        column: x => x.UserId,
                        principalTable: "user",
                        principalColumn: "Id_user",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "livro_autor",
                columns: table => new
                {
                    autor_id = table.Column<int>(type: "integer", nullable: false),
                    livro_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_livro_autor", x => new { x.autor_id, x.livro_id });
                    table.ForeignKey(
                        name: "FK_livro_autor_autor_id",
                        column: x => x.autor_id,
                        principalTable: "autor",
                        principalColumn: "Id_Autor",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_livro_autor_livro_id",
                        column: x => x.livro_id,
                        principalTable: "Livro",
                        principalColumn: "Id_Livro",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_emprestimo_LivroId",
                table: "emprestimo",
                column: "LivroId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_emprestimo_UserId",
                table: "emprestimo",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Livro_EditoraId",
                table: "Livro",
                column: "EditoraId");

            migrationBuilder.CreateIndex(
                name: "IX_Livro_GeneroId",
                table: "Livro",
                column: "GeneroId");

            migrationBuilder.CreateIndex(
                name: "IX_livro_autor_livro_id",
                table: "livro_autor",
                column: "livro_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "emprestimo");

            migrationBuilder.DropTable(
                name: "livro_autor");

            migrationBuilder.DropTable(
                name: "user");

            migrationBuilder.DropTable(
                name: "autor");

            migrationBuilder.DropTable(
                name: "Livro");

            migrationBuilder.DropTable(
                name: "editora");

            migrationBuilder.DropTable(
                name: "genero");
        }
    }
}
