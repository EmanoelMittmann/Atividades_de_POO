using Trabalho.Models.Domain;

namespace Trabalho.Models.Repository
{
    public interface IRepositoryBank : IBaseRepository<Bank>
    {
        
    }
}